import requests
import time
import concurrent.futures

url='http://localhost:8080/invocations'
json_obj = {
    "image_name": "input.png"
}
max = 500 #total no of requests to be sent

def call_api(i):
    print(f"Inference #{i+1}...")
    json_obj["image_name"]=f"input{i%10+1}.png"
    print(f"Payload #{i+1}...")
    print(json_obj)
    response = requests.post(url, json = json_obj)
    print(f"...Response #{i+1}")
    print(response.text)

start_time = time.time()
with concurrent.futures.ThreadPoolExecutor() as executor:
    result = executor.map(call_api, [i for i in range(max)])
end_time = time.time()
print("Total time taken by our program - "+str(end_time-start_time)+" seconds...")